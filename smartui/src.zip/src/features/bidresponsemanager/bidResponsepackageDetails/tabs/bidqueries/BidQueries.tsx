import './BidQueries.scss';

import { getServer } from 'app/common/appInfoSlice';
import { useAppDispatch, useAppSelector } from 'app/hooks';
import IQComment from 'components/iqcommentfield/IQCommentField';
import IQSearch from 'components/iqsearchfield/IQSearchField';
import Posts from 'components/posts/Posts';
import { CreateBidQueries, ResponseBidQueries } from 'features/bidmanager/stores/BidQueriesAPI';
import { loadBidQueriesByPackageAndBidder } from 'features/bidmanager/stores/BidQueriesSlice';
import React, { useEffect, useState } from 'react';
import { convertISOToDispalyFormat } from 'utilities/commonFunctions';
import { formatDate } from 'utilities/datetime/DateTimeUtils';

import { Box, InputLabel, Stack } from '@mui/material';


const Grouping = ({ data, groupKey, onResponseClick, readOnly }: any) => {
	var tinycolor = require('tinycolor2');
	// Group the data by companyName
	const groupedData = data?.reduce((groups: any, item: any) => {
		const groupValue = item[groupKey];
		if (!groups[groupValue]) {
			groups[groupValue] = [];
		}
		groups[groupValue].push(item);
		return groups;
	}, {});

	// Create a new array of grouped data objects
	const newArray = Object.keys(groupedData).map((groupValue) => ({
		groupValue,
		items: groupedData[groupValue],
	}));

	const QueryType = (value: any) => {
		return (
			value == 1 ? 'Public' : 'Private'
		)
	}
	return (
		<div>
			{newArray.map((group: any) => (
				<div>
					<div className='groupBy'>
						{groupKey == 'companyName' &&
							<div>
								{group?.items[0]?.companyThumbnail ?
									<img className="post-thumbnail" src={group?.items[0]?.companyThumbnail} />
									:
									<div
										className="post-thumbnail-word"
										style={{
											background: '#059cdf',
											color: tinycolor('#059cdf').isDark() ? 'white' : 'black',
										}}

									>{group?.groupValue?.substring(0, 1)}</div>
								}
							</div>
						}
						<span className='name'>
							{groupKey == 'companyName' ? group?.groupValue : QueryType(group?.groupValue)}
						</span>
					</div>
					<Posts
						posts={group?.items}
						readOnly={readOnly}
						emptyText={
							<>
								<span className="common-icon-BidQueries"></span>
								No Bid Queries Exist
							</>
						}
						onResponseClick={(value: any) => {
							onResponseClick(value);
						}}
					/>
				</div>
			))}
		</div>
	)
}

const BidQueries = (props: any) => {
	const dispatch = useAppDispatch();
	const appInfo = useAppSelector(getServer);
	const { BidQueriesData } = useAppSelector((state) => state.bidQueries);
	const [queriesData, setQueriesData] = useState([]);
	const [aliasQueriesData, setAliasQueriesData] = useState([]);
	const [query, setQuery] = useState<any>();
	const { selectedRecord } = useAppSelector((state) => state.bidResponseManager);
	const [group, setGroup] = useState<any>({
		value: '', status: ''
	});

	const groupOptions = [
		{ text: "Query Type", value: "privacy" },
		{ text: "Companies", value: "companyName" },
	];

	const filterOptions = [
		{
			text: "Query Type",
			value: "queryType",
			key: "queryType",
			// iconCls: "common-icon-name-id",
			children: {
				type: "checkbox",
				items: [{
					text: 'Private',
					id: 'private',
					key: 'private',
					value: 'private'

				}, {
					text: 'Public',
					id: 'public',
					key: 'public',
					value: 'public'
				}],
			},
		}
	];

	const [filters, setFilters] = React.useState<any>(filterOptions);

	React.useEffect(() => {
		dispatch(loadBidQueriesByPackageAndBidder({ appInfo: appInfo, packageId: selectedRecord?.id, bidderId: selectedRecord?.bidderUID }));
	}, [selectedRecord]);

	useEffect(() => {
		const finaldata: any = [];
		BidQueriesData?.map((data: any) => {
			var status = data?.queryResponse !== null ? false : true;
			finaldata.push({
				id: data?.id,
				name: data?.queryBy?.firstName + ' ' + data?.queryBy?.lastName,
				thumbnailUrl: data?.queryBy?.thumbnail,
				timestamp: formatDate(data?.queryDate),
				text: data?.queryText,
				isQuestion: true,
				companyId: data?.queryBy?.id,
				companyName: data?.queryBy?.companyName,
				companyThumbnail: data?.queryBy?.companyThumbnail,
				privacy: data?.queryResponse?.isPrivate ? 0 : 1,
				isReply: status,
				responseName: data?.queryResponse?.responseBy?.firstName + ' ' + data?.queryResponse?.responseBy?.lastName,
				responseTimestamp: formatDate(data?.queryResponse?.responseDate),
				responseThumbnailUrl: data?.queryResponse?.responseBy?.thumbnail,
				responseText: data?.queryResponse?.responseText,
			});
		});
		setQueriesData(finaldata);
		setAliasQueriesData(finaldata);
	}, [BidQueriesData]);

	const queryHandleClick = () => {
		const payLoad = {
			isPrivate: true,
			queryText: query
		};
		setQuery('');
		CreateBidQueries(appInfo, selectedRecord?.id, selectedRecord?.bidderUID, payLoad).then(() => {
			dispatch(loadBidQueriesByPackageAndBidder({ appInfo: appInfo, packageId: selectedRecord?.id, bidderId: selectedRecord?.bidderUID }));
		});
	};

	const responseClick = (data: any) => {
		const queryId = data.queryId;
		const payLoad = {
			responseText: data.responseText,
			isPrivate: (data.isPrivate == 0)
		};
		ResponseBidQueries(appInfo, selectedRecord?.id, selectedRecord?.bidderUID, queryId, payLoad).then(() => {
			dispatch(loadBidQueriesByPackageAndBidder({ appInfo: appInfo, packageId: selectedRecord?.id, bidderId: selectedRecord?.bidderUID }));
		});;
	};

	const handleOnSearchChange = (searchText: string) => {
		if (queriesData.length && searchText !== '') {
			const firstResult = queriesData.filter((obj: any) => {
				return JSON.stringify(obj).toLowerCase().includes(searchText.toLowerCase());
			});
			setQueriesData(firstResult);
		} else {
			setQueriesData(aliasQueriesData);
		}
	};
	const handleFilterChange = (filters: any) => {
		let filteredData: any = [...aliasQueriesData];
		if (filters?.queryType?.length > 0) {
			filteredData = filteredData.filter((rec: any) => {
				if (filters?.queryType?.includes('private') && rec?.privacy == 0) return rec;
				if (filters?.queryType?.includes('public') && rec?.privacy == 1) return rec;
			});
		}
		setQueriesData(filteredData);
	};
	const handleGroupChange = (group: any) => {
		if (group == undefined || group == '') {
			setGroup({
				value: group, status: false
			});
		}
		else {
			setGroup({
				value: group, status: true
			});
		}
	}
	return (
		<Box className="tab-bid-queries">
			<Stack direction="row" className="header-box">
				<span className="header-text">Bid Queries</span>
				<IQSearch groups={groupOptions}
					filters={filters}
					onSearchChange={(text: string) => handleOnSearchChange(text)}
					onFilterChange={(filters: any) => handleFilterChange(filters)}
					onGroupChange={(group: any) => handleGroupChange(group)}
				/>
			</Stack>
			{!props?.readOnly && (
				<>
					<InputLabel className='inputlabel'>Post a Query</InputLabel>
					<IQComment
						onChange={(event: any) => {
							setQuery(event.target.value);
						}}
						value={query}
						onButtonClick={queryHandleClick}
						placeholder={'Enter Your question here'}
					/>
				</>
			)}
			{group?.status == true ?
				<Grouping
					data={queriesData}
					groupKey={group?.value}
					onResponseClick={(value: any) => {
						responseClick(value);
					}}
					readOnly={props.readOnly}
				/> :
				<Posts
					posts={queriesData}
					readOnly={props?.readOnly}
					emptyText={
						<>
							<span className="common-icon-BidQueries"></span>
							No Bid Queries Exist
						</>
					}
					onResponseClick={(value: any) => {
						responseClick(value);
					}}
				/>
			}
		</Box>
	);
};

export default BidQueries;