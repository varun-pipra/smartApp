export const primaryIconSize= 'small';
export const secondaryIconSize = 'medium';

const globalStyles = {
    primaryColor: '#ed7431',
    secondaryColor: '',
    primaryButtonsSize: '',
    secondaryButtonSize: '',
    primaryButtonColor: '',
    secondaryButtonColor: ''
}

export default globalStyles;