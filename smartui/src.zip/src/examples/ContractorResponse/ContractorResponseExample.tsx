import { ContractorResponse } from "features/vendorcontracts/vendorcontractsdetails/ContractorResponse/ContractorResponse"

export const ContractorResponseExample = () => {
    return (
        < ContractorResponse contractorName={"swathi"} respondedOn={"2023-03-06T13:30:00Z"} responseType={2} />

    )
}