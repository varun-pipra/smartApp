import React, { useState, useMemo } from 'react';
import { Tabs, Tab, Box, Icon, Badge } from '@mui/material';

const NavTab = () => {
	return <div style={{ height: '100vh', border: '1px solid black' }}>
	</div>
};

export default NavTab;