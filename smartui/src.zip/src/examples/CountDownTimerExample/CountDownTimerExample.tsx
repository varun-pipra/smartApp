import React from 'react';
import  SUICountDownTimer from "sui-components/CountDownTimer/CountDownTimer";

const SUICountDownTimerExample = ()=>{
    return(<SUICountDownTimer targetDate='2023-01-26' />)
}

export default SUICountDownTimerExample;