import SUIDetailsPanel from 'sui-components/DetailsPanel/DetailsPanel';

const DrawerExample = (props: any) => {
    return (
        <SUIDetailsPanel mode="dailog" />
    );
}

export default DrawerExample;