import React from "react";
import SUIPayIntervalFrequency from "sui-components/PayIntervalFrequency/SUIPayIntervalFrequency";

const PayIntervalFrequencyExample = () => {
  return <SUIPayIntervalFrequency></SUIPayIntervalFrequency>;
};
export default PayIntervalFrequencyExample;
