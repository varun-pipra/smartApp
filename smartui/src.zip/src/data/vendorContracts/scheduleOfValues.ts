export const WorkItems = [
    {
        "name": "00176",
        "id": "403186db-1fb0-4469-a5e0-32f4db484011",
        "costType": "M - Materials",
        "costCode": "05050 Basic Metal Materials and Methods",
        "quantity": 1500,
        "unitCost": null,
        "bidValue": 100000.00,
        "description": null,
        "unitOfMeasure": "m3",
        "revisedBidValue": 0.00,
        "changeOrderAmount": 0.00
    },
    {
        "name": "00234",
        "id": "c3833975-a707-4a04-91cb-55c4c6dd3fd5",
        "costType": "M - Materials",
        "costCode": "05050 Basic Metal Materials and Methods",
        "quantity": 1500,
        "unitCost": null,
        "bidValue": 100000.00,
        "description": null,
        "unitOfMeasure": "m3",
        "revisedBidValue": 0.00,
        "changeOrderAmount": 0.00
    }
]
