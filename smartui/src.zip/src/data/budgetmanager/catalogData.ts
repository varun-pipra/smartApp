export const catalogData = {
    "id": 2233495,
    "productId": 1,
    "src": "https://5ba09a787d0a4ea1bc0f0c1420152d1c.smartappbeta.com/EnterpriseDesktop/handlers/FileStoreImageHandler.ashx?key=gs%3a%2f%2fsmartapp-appzones%2f5ba09a787d0a4ea1bc0f0c1420152d1c%2fiqadmin%2fdynamic%2f2310%2fmtmirxeg%2fac394fc724a44e658b38746ece57ea8c.png",
    "price": 50,
    "itemPrice": 50,
    "sku": "CI1",
    "description": "",
    "variantId": 1,
    "matrixId": 1,
    "referenceId": "54228",
    "categoryId": 2233429,
    "subCategoryId": 2233432,
    "name": "Catalog Item 1",
    "CategoryName": "Category",
    "CIDefName": "CI Definition",
    "quantity": 1,
    "distributorName": "Select Distributor",
    "distributorId": 2036785,
    "isPack": false,
    "type": 0,
    "allowPriceOverride": false,
    "images": [
      {
        "isDefault": false,
        "url": "https://5ba09a787d0a4ea1bc0f0c1420152d1c.smartappbeta.com/EnterpriseDesktop/handlers/FileStoreImageHandler.ashx?key=gs%3a%2f%2fsmartapp-appzones%2f5ba09a787d0a4ea1bc0f0c1420152d1c%2fiqadmin%2fdynamic%2f2310%2fmtmirxeg%2fac394fc724a44e658b38746ece57ea8c.png"
      }
    ],
    "assemblyExplode": false,
    "distributors": [
      {
        "website": "",
        "logo": "https://central.smartappbeta.com/skins/base/img/A_200dp.png",
        "idAndName": "1412422_ABC Inc",
        "id": 1412422,
        "name": "ABC Inc"
      },
      {
        "website": "gs://smartapp-appzones/5ba09a787d0a4ea1bc0f0c1420152d1c/iqadmin/dynamic/2309/xypfnqqo/vendor.jpg",
        "logo": null,
        "idAndName": "2036785_CE Vendor",
        "id": 2036785,
        "name": "CE Vendor"
      }
    ],
    "manufacturer": {
      "website": null,
      "logo": null,
      "idAndName": "0_",
      "id": 2036785,
      "name": 'CE Vendor'
    },
    "cartId": "1-null",
    "labelNames": {}
  } 